/* Uso de funciones, variables y estructuras de control */

var a = 3;
var b = 4;
var c = 0;

function suma() {
 c = a + b;
}


suma();