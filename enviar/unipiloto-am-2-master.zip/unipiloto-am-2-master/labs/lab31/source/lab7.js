 /* Uso de funciones, variables y estructuras de control */

var number_one = 2;

var number_two = 22828282;

// Declarando la función max()
function max(){
	if(number_one > number_two){
		alert("El número " + number_one + " es mayor que número " + number_two);
	} else {
		alert("el número de la variable 'number_two' " + number_two + " es mayor que el número de la variable 'number_one' " + number_two);
	}
}

// Haciendo uso de la funcion `max()`
max();
