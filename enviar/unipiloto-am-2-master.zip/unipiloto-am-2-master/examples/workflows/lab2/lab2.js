(function test(){
	var number_a = 424494;

	var number_b = 484848;

	function add_numbers(number_a, number_b){

		return number_a + number_b;
	}

	console.log(add_numbers(number_a, number_b));
	
})();